﻿#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;


void printField(const vector<char>& field) {
    cout << "\n";
    for (int i = 0; i < 9; i += 3) {
        cout << " " << field[i] << " | " << field[i + 1] << " | " << field[i + 2] << " \n";
        if (i < 6) cout << "---+---+---\n";
    }
    cout << "\n";
}


bool checkWin(const vector<char>& field, char player) {
    const int winCombos[8][3] = {
        {0, 1, 2}, {3, 4, 5}, {6, 7, 8},
        {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
        {0, 4, 8}, {2, 4, 6}
    };
    for (auto& combo : winCombos) {
        if (field[combo[0]] == player && field[combo[1]] == player && field[combo[2]] == player) {
            return true;
        }
    }
    return false;
}


void ticTacToe() {
    vector<char> field = { '1','2','3','4','5','6','7','8','9' };
    char currentPlayer = 'X';
    int moves = 0;

    while (true) {
        printField(field);
        int move;
        cout << "Игрок " << currentPlayer << ", введите номер клетки: ";
        cin >> move;

        if (cin.fail() || move < 1 || move > 9 || field[move - 1] == 'X' || field[move - 1] == 'O') {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Некорректный ход. Попробуйте снова.\n";
            continue;
        }

        field[move - 1] = currentPlayer;
        moves++;

        if (checkWin(field, currentPlayer)) {
            printField(field);
            cout << "Игрок " << currentPlayer << " победил!\n";
            break;
        }
        if (moves == 9) {
            printField(field);
            cout << "Ничья!\n";
            break;
        }

        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }
}


class Character {
public:
    string name;
    int health, attack;

    Character(string n, int h, int a) : name(n), health(h), attack(a) {}

    void attackTarget(Character& target) {
        cout << name << " атакует " << target.name << " и наносит " << attack << " урона.\n";
        target.health -= attack;
    }
};


void battle() {
    Character hero("Герой", 100, 20);
    Character monster("Монстр", 80, 15);

    while (hero.health > 0 && monster.health > 0) {
        cout << "\n" << hero.name << " (Здоровье: " << hero.health << ") vs " << monster.name << " (Здоровье: " << monster.health << ")\n";
        cout << "1. Атаковать  2. Пропустить ход\n";
        int choice;
        cin >> choice;

        if (choice == 1) hero.attackTarget(monster);
        if (monster.health > 0) monster.attackTarget(hero);
    }

    if (hero.health > 0) cout << "Герой победил!" << endl;
    else cout << "Монстр победил!" << endl;
}

int main() {
    setlocale(LC_ALL, "Russian");
    int choice;

    while (true) {
        cout << "\nВыберите игру:" << endl;
        cout << "1. Крестики-нолики" << endl;
        cout << "2. Битва с монстром" << endl;
        cout << "3. Выход" << endl;
        cout << "Ваш выбор: ";
        cin >> choice;

        if (choice == 1) {
            ticTacToe();
        }
        else if (choice == 2) {
            battle();
        }
        else if (choice == 3) {
            cout << "Выход из программы." << endl;
            break;
        }
        else {
            cout << "Неверный выбор, попробуйте снова." << endl;
        }
    }
    return 0;
}
